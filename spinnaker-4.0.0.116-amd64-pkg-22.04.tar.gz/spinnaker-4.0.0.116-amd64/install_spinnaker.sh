#!/bin/bash

set -o errexit

MY_YESNO_PROMPT='[Y/n] $ '

echo "This is a script to assist with installation of the Spinnaker SDK."
echo "Would you like to continue and install all the Spinnaker SDK packages?"
echo -n "$MY_YESNO_PROMPT"
read confirm
if ! ( [ "$confirm" = "y" ] || [ "$confirm" = "Y" ] || [ "$confirm" = "yes" ] || [ "$confirm" = "Yes" ] || [ "$confirm" = "" ] )
then
    exit 0
fi

echo

set +o errexit
EXISTING_VERSION=$(dpkg -s spinnaker 2> /dev/null | grep '^Version:' | sed 's/^.*: //')
set -o errexit

if [ ! -z "$EXISTING_VERSION" ]; then
    echo "A previous installation of Spinnaker has been detected on this machine (Version: $EXISTING_VERSION). Please consider uninstalling the previous version of Spinnaker before continuing with this installation." >&2
    echo "Would you like to continue with this installation?"
    echo -n "$MY_YESNO_PROMPT"
    read confirm
    if ! ( [ "$confirm" = "y" ] || [ "$confirm" = "Y" ] || [ "$confirm" = "yes" ] || [ "$confirm" = "Yes" ] || [ "$confirm" = "" ] )
    then
        exit 0
    fi
fi

echo "Installing Spinnaker packages..."


sudo dpkg -i libgentl_*.deb
sudo dpkg -i libspinnaker_*.deb
sudo dpkg -i libspinnaker-dev_*.deb
sudo dpkg -i libspinnaker-c_*.deb
sudo dpkg -i libspinnaker-c-dev_*.deb
sudo dpkg -i libspinvideo_*.deb
sudo dpkg -i libspinvideo-dev_*.deb
sudo dpkg -i libspinvideo-c_*.deb
sudo dpkg -i libspinvideo-c-dev_*.deb
sudo apt-get install -y ./spinview-qt_*.deb
sudo dpkg -i spinview-qt-dev_*.deb
sudo dpkg -i spinupdate_*.deb
sudo dpkg -i spinupdate-dev_*.deb
sudo dpkg -i spinnaker_*.deb
sudo dpkg -i spinnaker-doc_*.deb

echo
echo "Would you like to add a udev entry to allow access to USB hardware?"
echo "  If a udev entry is not added, your cameras may only be accessible by running Spinnaker as sudo."
echo -n "$MY_YESNO_PROMPT"
read confirm
if [ "$confirm" = "y" ] || [ "$confirm" = "Y" ] || [ "$confirm" = "yes" ] || [ "$confirm" = "Yes" ] || [ "$confirm" = "" ]
then
    echo "Launching udev configuration script..."
    sudo sh configure_spinnaker.sh
fi

echo
echo "Would you like to set USB-FS memory size to 1000 MB at startup (via /etc/rc.local)?"
echo "  By default, Linux systems only allocate 16 MB of USB-FS buffer memory for all USB devices."
echo "  This may result in image acquisition issues from high-resolution cameras or multiple-camera set ups."
echo "  NOTE: You can set this at any time by following the USB notes in the included README."
echo -n "$MY_YESNO_PROMPT"
read confirm
if [ "$confirm" = "y" ] || [ "$confirm" = "Y" ] || [ "$confirm" = "yes" ] || [ "$confirm" = "Yes" ] || [ "$confirm" = "" ]
then
    echo "Launching USB-FS configuration script..."
    sudo sh configure_usbfs.sh
fi

echo

echo "Would you like to have Spinnaker prebuilt examples available in your system path?"
echo "  This allows Spinnaker prebuilt examples to run from any paths on the system."
echo "  NOTE: You can add the Spinnaker example paths at any time by following the \"RUNNING PREBUILT UTILITIES\""
echo "        section in the included README."
echo -n "$MY_YESNO_PROMPT"

read confirm
if [ "$confirm" = "y" ] || [ "$confirm" = "Y" ] || [ "$confirm" = "yes" ] || [ "$confirm" = "Yes" ] || [ "$confirm" = "" ]
then
    echo "Launching Spinnaker paths configuration script..."
    sudo sh configure_spinnaker_paths.sh
fi

echo

ARCH=$(ls libspinnaker_* | grep -oP '[0-9]_\K.*(?=.deb)' || [[ $? == 1 ]])
if [ "$ARCH" = "amd64" ]; then
    BITS=64
elif [ "$ARCH" = "i386" ]; then
    BITS=32
fi

if [ -z "$BITS" ]; then
    echo "Could not automatically add the Spinnaker GenTL Producer to the GenTL environment variable."
    echo "To use the Spinnaker GenTL Producer, please follow the GenTL Setup notes in the included README."
else
    echo "Would you like to have the Spinnaker GenTL Producer added to GENICAM_GENTL${BITS}_PATH?"
    echo "  This allows GenTL consumer applications to load the Spinnaker GenTL Producer."
    echo "  NOTE: You can add the Spinnaker producer to GENICAM_GENTL${BITS}_PATH at any time by following the GenTL Setup notes in the included README."
    echo -n "$MY_YESNO_PROMPT"

    read confirm
    if [ "$confirm" = "y" ] || [ "$confirm" = "Y" ] || [ "$confirm" = "yes" ] || [ "$confirm" = "Yes" ] || [ "$confirm" = "" ]
    then
        echo "Launching GenTL path configuration script..."
        sudo sh configure_gentl_paths.sh $BITS
    fi
fi

echo
echo "Installation complete."

echo

echo "Thank you for installing the Spinnaker SDK."
exit 0
